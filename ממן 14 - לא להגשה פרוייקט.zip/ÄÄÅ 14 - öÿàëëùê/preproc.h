/*The header file of the preproc.c file containing comments and function signatures*/
#ifndef PREPROC_H
#define PREPROC_H
#include "global.h"


/*************************************************************************************************/

typedef struct node {
    char name[MAX_MCRO_NAMES];
    char line[MAX_MCRO_LINES][MAX_LINE_LENGTH];
    int line_num;
    struct node *next;
} mcro;

typedef struct mcro_table{
    mcro* macros;
    int count; /*How many macros exist*/
    int capacity; /*How much is currently allocated in memory*/
} mcro_table;

/*************************************************************************************************/

/*A function that creates an empty table of macros*/
mcro_table* new_table(void);


/*A function whose main role is to scan an assembly file and add new macros to the macro table.
 *The function locates a line starting with "mcro" and ending with "endmcro".
 *1 will be returned if all tests passed successfully and 0 if errors were detected.*/
int add_mcro(const char* filename , mcro_table* table);


/*Searches for macros in a table by name.
 *The function scans the table and compares the name of each macro to the name given as a parameter.*/
mcro* find_mcro(mcro_table* table , const char *name);


/*A function that replaces macros in a file accepts an .as file as input and returns an .am file as output.
 *In case of success, 1 will be returned, in case of failure, 0 will be returned.*/
int replace_mcro(const char *input_file , const char *output_file , mcro_table *table );

/*A function that "connects everything", creates a table, reads the macros, swaps macro uses and frees memory*/
int mcro_exec(const char *input_file , const char *output_file);

/*Iterates over all the macros in the linked list and frees each one with free.*/
void free_mcro(mcro_table *table);


#endif
