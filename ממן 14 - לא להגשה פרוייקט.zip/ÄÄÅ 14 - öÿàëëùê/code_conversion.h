#include <stdio.h>
#include "global.h"
#include "handletext.h"

#ifndef CODE_CONVERSION_H
#define CODE_CONVERSION_H
typedef struct {
    unsigned short short_num;
    int address;
    int line_num;
    int is_data;
} code_conversion;
typedef struct command_parts {
    char *source;  /* מקור (יכול להיות רגיסטר, מספר או תווית) */
    char *dest;    /* יעד (יכול להיות רגיסטר, מספר או תווית) */
    int opcode;    /* קוד פעולה (opcode) */
} command_parts;

/*Increases the array of the pointer to the next position to store a new binary word in memory.
The function uses realloc to expand the array. Initializes the fields. Returns 1 on success, 0 on failure.*/
int inc_mem(code_conversion **code, int counter);

/*The purpose of the function is to translate the command into a binary word.
The function determines the upper 4 bits and identifies the addressing method.*/
unsigned short command_to_short(command_parts *command);

/*Purpose of the function If the command includes registers, it converts the register numbers to bits 0-7
Checks if dest and source are registers and sorts them by bits*/
unsigned short register_to_short(command_parts *command);
#endif //CODE_CONVERSION_H
