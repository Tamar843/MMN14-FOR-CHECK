#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "first_pass.h"
#include "ErrorMessage.h"
#include "preproc.h"
#include "table.h"
#include "Errors.h"
#include "util.h"
#include "lexer.h"
#include "code_conversion.h"
#include "global.h"
#include "handletext.h"

int exe_first_pass(char *filename){
    FILE *fp;
    char line[MAX_LINE_LENGTH+5];
    int line_num =0;
    int IC = IC_VALUE;
    int DC = 0;

    /* data structures */
    label_address *label_table = NULL;
    int label_count = 0;

    other_table *externs = NULL;
    int externs_count = 0;

    other_table *entries = NULL;
    int entries_count = 0;

    fp = fopen(filename, "r");
    if (!fp) {
        print_errors(ERROR_NUM_1);
        return 1; // Error opening file
    }

while(fgets(line, sizeof(line), fp)) {
        line_num++;

    remove_whitespace_str(line);
    remove_spaces_next_to_comma(line);

        if (line[0] == '\n' || line[0] == ';') {
            continue; // Skip empty lines and comments
        }

        if (strcmp(line, "\n") == 0) {
            continue; // Skip empty lines
        }

        char temp[MAX_LINE_LENGTH+1];
        char *token;
        char *label = NULL;
        char *instruction;

        strcpy(temp, line);
        token = strtok(temp, " \t\n"); // Tokenize the line

        if (token && token[strlen(token) - 1] == ':') { // Check for label
            token[strlen(token) - 1] = '\0'; // Remove the colon
               label = help_strdup(token);
               token = strtok(NULL, " \t\n"); // Get the next token
        }

        if(!token){
          if(label) free(label); // Free label if it was allocated
          continue; // If no instruction, skip to next line
          }
          instruction = token;

          if(is_instruction(instruction)){
              if (strcmp(instruction, ".extern") == 0) {
                  /* .extern NAME */
                  char *name = strtok(NULL, " \t\n");
                  if (name) {
                      insert_other_label(&externs, &externs_count, name, line_num);
                  }
              } else if (strcmp(instruction, ".entry") == 0) {
                  /* .entry NAME -> שמור בטבלת entries להידור ב־second pass */
                  char *name = strtok(NULL, " \t\n");
                  if (name) {
                      insert_other_label(&entries, &entries_count, name, line_num);
                  }
              } else if (strcmp(instruction, ".data") == 0) {
                  /* parse numbers, הוספת ל־DC */
                  if (label) {
                      insert_label_table(&label_table, &label_count, label, DC, line_num, 1);
                  }
                  /* פרשנות .data: עדכני DC לפי כמות האיברים */
                  /* לדוגמא: parse CSV of ints and increment DC per value */
              } else if (strcmp(instruction, ".string") == 0) {
                  if (label) {
                      insert_label_table(&label_table, &label_count, label, DC, line_num, 1);
                  }
              }

              }else if (is_opcode(instruction)){
                if (label) {
                    insert_label_table(&label_table, &label_count, label, IC, line_num, 0);
                }
                }else{
                    fprintf(stderr, "Line %d: Unknown instruction '%s'\n", line_num, instruction);
                }

                if (label) {
                    free(label); // Free label if it was allocated
                }
              }
    fclose(fp);

   update_data_labels(label_table , label_count, IC);

   if(!check_each_label_once(label_table ,label_count){
        free_label_table(label_table, label_count);
        free_other_table(entries, entries_count);
        free_other_table(externs, externs_count);
        return 1; // Error: duplicate labels found
    }
       free_label_table(label_table, label_count);
        free_other_table(entries, entries_count);
        free_other_table(externs, externs_count);
    return 0; // Success

       }

