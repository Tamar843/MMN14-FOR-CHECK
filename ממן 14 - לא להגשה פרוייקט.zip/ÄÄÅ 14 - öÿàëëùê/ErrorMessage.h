#ifndef ERRORMESSAGE_H
#define ERRORMESSAGE_H

#define ERROR_NUM_1 1
#define ERROR_NUM_2 2
#define ERROR_NUM_3 3
#define ERROR_NUM_4 4
#define ERROR_NUM_5 5
#define ERROR_NUM_6 6
#define ERROR_NUM_7 7
#define ERROR_NUM_8 8
#define ERROR_NUM_9 9

int print_errors(int error_code);

#endif //ERRORMESSAGE_H
