
// בקובץ הזה אני צריכה לממש את כל הקבועים שרלוונטים לכל הפרוייקט
#ifndef GLOBAL_H
#define GLOBAL_H
/*According to the project guidelines, the maximum length is 80*/
#define MAX_LINE_LENGTH 80
#define MAX_MCRO_LINES 100
#define MAX_MCRO_NAMES 30
#define IC_VALUE 100
#define INSTRUCTIONS_COUNT 4
#define MAX_LABEL_LENGTH 31



typedef struct location {
    char *file_name;
    int line_num;
} location;

typedef struct line_data {
    char *file_name;
    short number;
    char *data;
} line_data;

#endif //GLOBAL_H
