#include <stdio.h>
#include "global.h"
#include "lexer.h"



#ifndef TABLE_H
#define TABLE_H
typedef enum { CODE_SYMBOL, DATA_SYMBOL, EXTERNAL_SYMBOL, ENTRY_SYMBOL } SymbolType;

/* טבלת סמלים (label table) */
typedef struct label_address {
    int address;        /* כתובת יחסית (לפני עדכון data: IC או DC בהתאם) */
    char *label_name;   /* שם התווית (מוקצה דינמית) */
    int assembly_line;  /* שורת הקוד שבה הוגדרה התווית (לשגיאות) */
    int is_data_line;   /* 1 אם התווית שייכת ל־.data/.string, 0 אחרת */
} label_address;

/* טבלאות נוספות: entries / externs (מאוחסנות בערכים דומים) */
typedef struct other_table {
    char *label_name;   /* שם התווית (מוקצה דינמית) */
    int assembly_line;  /* שורה שבה הופיעה ההוראה (.entry/.extern) */
    int address;        /* כתובת שנפתרה (או -1 אם עדיין לא נפתרה) */
} other_table;

static char *help_strdup(const char *s);
/* הוספת תווית לטבלת הסמלים (מעדכן את המונה). */
int insert_label_table(label_address **label_table, int *label_count, const char *label_name, int address, int line_number, int is_data_line);

/* הוספת ערך לטבלת other_table (entries או externs).
 * מגדיל ומעדכן את *count. address מאופס ל־-1. */
int insert_other_label(other_table **table, int *count,const char *label_name, int line_number);

/* מחפש כתובת של תווית בטבלת הסמלים; מחזיר address או -1 אם לא נמצא */
int find_label_address(label_address *label_table, int label_count, const char *label_name);

/* מעדכן את כל תוויות ה־data: מוסיף את IC (הכתובת ההתחלתית של קוד) לכתובות שלהם.
 * הנחיה: בשלבי first-pass, עבור כל תווית data שמרנו את ערך ה־DC המקומי; כעת יש להוסיף IC. */
void update_data_labels(label_address *label_table, int label_count, int IC);

/* בודק שאין כפילויות שמות תווית; מדווח ומחזיר 0 אם יש כפילות, אחרת 1. */
int check_each_label_once(label_address *label_table, int label_count);

/* 'יישור' טבלת entries — מחפש כל שם בטבלת הסמלים וממלא address בטבלת entries;
 * מחזיר 1 אם כל ה־entries נפתרו, אחרת 0 (וגם מדפיס הודעות שגיאה עבור כל entry שלא נמצא). */
int resolve_entries(other_table *entries, int entries_count, label_address *label_table, int label_count);

/* משחרר טבלת סמלים ושמות */
void free_label_table(label_address *label_table, int label_count);
void free_other_table(other_table *table, int count);

#endif //TABLE_H
