#include <stdio.h>
#include <stdlib.h>

extern int mcro_exec(const char*, const char*);

int main(void) {
    const char *tests[] = {
        "test1.as", "test2.as", "test3.as",
        "test4.as", "test5.as", "test6.as.as"
    };
    for (int i=0; i<6; i++) {
        char out[32];
        sprintf(out, "out%d.am", i+1);
        printf("=== Running test %s -> %s ===\n", tests[i], out);
        if (mcro_exec(tests[i], out))
            printf("Success\n\n");
        else
            printf("FAIL\n\n");
    }
    return 0;
}
