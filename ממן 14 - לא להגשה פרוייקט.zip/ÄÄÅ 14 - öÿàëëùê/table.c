#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "global.h"
#include "handletext.h"
#include "lexer.h"
#include "code_conversion.h"
#include "ErrorMessage.h"
#include "table.h"
#include <stdio.h>
#include <stdlib.h>

static char *help_strdup(const char *s){
char *p;
size_t len;
if(s==NULL){
    return NULL;
    }
len = strlen(s)+1;
p = (char *)malloc(len);
if(p==NULL){
    print_errors(ERROR_NUM_7);
    return NULL;
    }
    memcpy(p, s, len);
return p;
}

int insert_label_table(label_address **label_table, int *label_count, const char *label_name, int address, int line_number, int is_data_line){
  label_address *ptr;
  char *name_copy;
  int i;

  if(label_name == NULL || label_table == NULL || label_count == NULL) {
    return 0; /*Invalid parameters*/
  }

  name_copy = help_strdup(label_name);
  if(name_copy == NULL) {
    print_errors(ERROR_NUM_7);
    free(name_copy);
    return 0; /*Memory allocation failed*/
  }
  *label_table = ptr;
  i = *label_count;


  (*label_table)[i].label_name = name_copy; /*Copy the label name*/
  (*label_table)[i].address = address; /*Set the address*/
  (*label_table)[i].assembly_line = line_number; /*Set the line number*/
  (*label_table)[i].is_data_line = is_data_line ? 1:0;/*Set if it's a data line*/


  (*label_count)++; /*Increase the count of labels*/
    rerurn 1;
}
int insert_other_label(other_table **table, int *count,const char *label_name, int line_number){
    other_table *ptr;
    char *name_copy;
    int i;

    if(label_name == NULL || table == NULL || count == NULL) {
        return 0; /*Invalid parameters*/
    }

    name_copy = help_strdup(label_name);
    if(name_copy == NULL) {
        print_errors(ERROR_NUM_7);
        free(name_copy);
        return 0; /*Memory allocation failed*/
    }

    ptr = (other_table *)realloc(*table, (size_t)(*count + 1) * sizeof(other_table));
    if(ptr == NULL) {
        print_errors(ERROR_NUM_7);
        free(name_copy);
        return 0; /*Memory allocation failed*/
    }
    *table = ptr;
    i = *count;
    (*table)[i].label_name = name_copy; /*Copy the label name*/
    (*table)[i].assembly_line = line_number; /*Set the line number*/
    (*table)[i].address = -1; /*Set address to -1 (not resolved yet)*/

    (*count)++; /*Increase the count of labels*/
    return 1;
}
int find_label_address(label_address *label_table, int label_count, const char *label_name) {
  int i;
    if (label_table == NULL || label_name == NULL) {
        return -1; /*Invalid parameters*/
    }
    for (i = 0; i < label_count; i++) {
        if (label_table[i].label_name && strcmp(label_table[i].label_name, label_name) == 0) {
            return label_table[i].address; /*Return the address of the label*/
        }
    }
    return -1; /*Label not found*/
}
void update_data_labels(label_address *label_table, int label_count, int IC) {
    int i;
    if (label_table == NULL) {
        return; /*Invalid parameters*/
    }
    for (i = 0; i < label_count; i++) {
        if (label_table[i].is_data_line) {
            label_table[i].address += IC; /*Update the address by adding IC*/
        }
    }
}

int check_each_label_once(label_address *label_table, int label_count) {
    int i, j;
    if (label_table == NULL) {
        return 1; /*Invalid parameters*/
    }
    for (i = 0; i < label_count; i++) {
      if(label_table[i].label_name == NULL) {
            continue; /*Skip if label name is NULL*/
        }
        for (j = i + 1; j < label_count; j++) {
            if (label_table[j].label_name == NULL) continue;
            if (strcmp(label_table[i].label_name, label_table[j].label_name) == 0) {
                fprintf(stderr, ERROR_NUM_9, label_table[j].label_name, label_table[j].assembly_line, label_table[i].assembly_line);
                return 0;
                }
            }
    }
    return 1; /*No duplicates found*/
}

int resolve_entries(other_table *entries, int entries_count, label_address *label_table, int label_count){
  int i;
  int success = 1;
  for(i = 0 ;i <entries_count; i++){
    if(entries[i].label_name == NULL{
        continue; /*Skip if label name is NULL*/
    }
    entries[i].address = find_label_address(label_table, label_count, entries[i].label_name);
if(entries[i].address == -1){
    fprintf(stderr, "Error: .entry for label '%s' (line %d) but label not defined.\n",
entries[i].label_name, entries[i].assembly_line);
success = 0; /*Entry not resolved*/
}
        }
    return success; /*Return 1 if all entries resolved, otherwise 0*/
    }


void free_label_table(label_address *label_table, int label_count) {
    int i;
    if (label_table == NULL) {
        return; /*Invalid parameters*/
    }
    for (i = 0; i < label_count; i++) {
        if (label_table[i].label_name) free(label_table[i].label_name);
    }
    free(label_table); /*Free the label table itself*/
}

void free_other_table(other_table *table, int count) {
    int i;
    if (table == NULL) {
        return; /*Invalid parameters*/
    }
    for (i = 0; i < count; i++) {
        if (table[i].label_name) free(table[i].label_name);
    }
    free(table); /*Free the other table itself*/
}
