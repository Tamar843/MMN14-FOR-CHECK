//
// Created by USER on 15/06/2025.
//

#ifndef FIRST_PASS_H
#define FIRST_PASS_H

int exe_first_pass(char *filename);

typedef struct {
    int address;
    char *label_name;
    int assembly_line;
    int is_data_line;
} label_address;

typedef struct {
    char *label_name;
    int assembly_line;
} other_table;

typedef struct {
    unsigned short short_num;
} code_conv;

typedef struct {
    char *file_name;
    short number;
    char *data;
} line_data;


#endif //FIRST_PASS_H
