#include <stdio.h>
#include <stdlib.h>

/* הצהרה על הפונקציה הראשית בקדם-אסמבלר */
extern int mcro_exec(const char *input_file, const char *output_file);

int main() {
    const int NUM_TESTS = 6;
    char input[20];
    char output[20];

    for (int i = 1; i <= NUM_TESTS; i++) {
        sprintf(input, "test%d.as", i);
        sprintf(output, "out%d.am", i);

        printf("=== Running test%d ===\n", i);
        if (mcro_exec(input, output)) {
            printf("✅ test%d succeeded. Output -> %s\n\n", i, output);
        } else {
            printf("❌ test%d failed to process file.\n\n", i);
        }
    }

    return 0;
}
