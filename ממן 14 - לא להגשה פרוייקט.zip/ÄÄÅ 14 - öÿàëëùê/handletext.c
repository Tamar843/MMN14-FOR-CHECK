#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "global.h"
#include "handletext.h"

#include "ErrorMessage.h"

void remove_whitespace_str(char str[]){
    int src=0; /*Pointer to the location to read from the string*/
    int dst=0;/*Pointer to the write location*/
    int in_space=1; /*We are at the beginning of a space*/
        while (str[src]==' ' || str[src]=='\t') { /*A loop that skips all spaces and tabs at the beginning of a string*/
                src++;
        }
    while (str[src]!='\0') {
        if (str[src]==' ' || str[src]=='\t') {
            if (!in_space) {
                str[dst++]=' ';
                in_space=1;
            }
        } else { /*We will enter and indicate that we are no longer in a space*/
            str[dst++]=str[src];
            in_space=0;
        }
        src++;
        }
    if (dst>0 && str[dst-1]==' ') {
        dst--; /*If there is a trailing space at the end of the string, it is deleted.*/

    }
    str[dst]='\0';

    }
char *copy_text(FILE *fp, fpos_t *pos, int length){
    char *text = (char *)malloc(length + 1); /*Allocates memory for a new string of length length + 1*/
    if (!text) {
        print_errors(ERROR_NUM_7);
        return NULL;
    }
    fsetpos(fp, pos); /* Restore the position*/
    fread(text, sizeof(char), length, fp); /*Read the text*/
    text[length] = '\0'; /*Null-terminate the string*/
    return text;
}

int is_space_or_tab(char c) {
    if (c== ' ' || c == '\t') {
        return 1; /*It's a space or tab*/
    }
    return 0; /*It's not a space or tab*/
}
void remove_spaces_next_to_comma(char *str) {
    int i=0;
    while (str[i]!='\0') {
        if (str[i] == ',') {
          /*Removes spaces and tabs before the comma*/
            while (i > 0 && (str[i - 1] == ' ' || str[i - 1] == '\t')) {
                int j = i - 1;
                while (str[j] != '\0') {
                    str[j] = str[j + 1];
                    j++;
                }
                i--;
            }
            /*Removes spaces and tabs after the comma*/
            while (str[i + 1] == ' ' || str[i + 1] == '\t') {
                int j = i + 1;
                while (str[j] != '\0') {
                    str[j] = str[j + 1];
                    j++;
                }
            }
        }
        i++;
    }
}