#include "ErrorMessage.h"
#include <stdio.h>
#include <stdlib.h>

int print_errors(int error_code) {
    switch(error_code) {
        case ERROR_NUM_1:
            fprintf(stderr, "Error opening file.\n");
        break;
        case ERROR_NUM_2:
            fprintf(stderr, "Not enough memory for new_table.\n");
        break;
        case ERROR_NUM_3:
            fprintf(stderr, "The macro has more than one definition.\n");
        break;
        case ERROR_NUM_4:
            fprintf(stderr, "Starting a new macro before the previous macro ends.\n");
        break;
        case ERROR_NUM_5:
            fprintf(stderr, "Error - There is an endmcro before opening mcro.\n");
        break;
        case ERROR_NUM_6:
            fprintf(stderr, "Error - too many lines.\n");
        break;
        default:
            fprintf(stderr, "Unknown error.\n");
        break;
        case ERROR_NUM_7:
            fprintf(stderr, "Memory allocation failed.\n");
        break;
        case ERROR_NUM_8:
            fprintf(stderr, "Error -Number out of range.\n");
        break;
        case ERROR_NUM_9:
            fprintf(stderr, "Error: duplicate label '%s' defined at line %d (previous at line %d");
    }
    return error_code;
}
