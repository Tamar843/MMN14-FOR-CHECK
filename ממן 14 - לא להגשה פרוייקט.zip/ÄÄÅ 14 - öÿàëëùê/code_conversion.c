/*Converting commands to binary words*/
//הופך פקודות לקוד בינארי
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "code_conversion.h"
#include "global.h"
#include "handletext.h"
#include "lexer.h"
#include "ErrorMessage.h"

int inc_mem(code_conversion **code, int counter) {
    code_conversion *new_code = realloc(*code, (counter + 1) * sizeof(code_conversion));
    if (!new_code) {
        print_errors(ERROR_NUM_7); /* Memory error*/
        return 0;
    }
    /**************Initializes the new line in memory.***************************/
    *code = new_code;
    (*code)[counter].short_num = 0;
    (*code)[counter].address = 0;
    (*code)[counter].line_num = 0;
    (*code)[counter].is_data = 0;
    return 1;
}
   /*****************************************/


unsigned short command_to_short(command_parts *command) {
    unsigned short result = 0;
    int opcode = command->opcode;
    int src_mode = 0, dest_mode = 0;

    /*Stores 4 bits of opcode in locations 8-11*/
    result |= (opcode & 0xF) << 8;

/*Identifies the operand type and stores it in bits 6-7*/
    if (command->source) {
        if (is_register(command->source))
            src_mode = 1;  // Register
        else if (is_number(command->source))
            src_mode = 0;  // Immediate
        else if (is_valid_label(command->source))
            src_mode = 2;  // Label
        result |= (src_mode & 0x3) << 6;
    }

    /*Identifies the type of operand and stores it in bits 4-5*/
    if (command->dest) {
        if (is_register(command->dest))
            dest_mode = 1;
        else if (is_number(command->dest))
            dest_mode = 0;
        else if (is_valid_label(command->dest))
            dest_mode = 2;
        result |= (dest_mode & 0x3) << 4;
    }

    return result;
}
unsigned short register_to_short(command_parts *command) {
    unsigned short result = 0;
    int src_reg = -1, dest_reg = -1;

    /*Encodes the register numbers into a 12-bit code*/
    if (is_register(command->source))
        src_reg = command->source[1] - '0';

    if (is_register(command->dest))
        dest_reg = command->dest[1] - '0';

    if (src_reg != -1)
        result |= (src_reg & 0x7) << 4;
    if (dest_reg != -1)
        result |= (dest_reg & 0x7);

    return result;
}

unsigned short num_to_short(char *num_str) {
    int num = atoi(num_str);
    unsigned short result = 0;
    if (!num_str) {
        print_errors(ERROR_NUM_2);
        return 0;
    }
    /*Checking the correct range*/
    if (num < -2048 || num > 2047) {
        print_errors(ERROR_NUM_8);  /*number out of range*/
        return 0;
    }
    if (num < 0)  { /*Converts a negative number to 2's complement in 12 bits*/
        result = (unsigned short)(num + (1 << 12));
    } else {
        result = (unsigned short)(num);
    }
    return result;
}

char short_to_bin(unsigned short num, char *bin_str) {
    if (!bin_str) {
        print_errors(ERROR_NUM_2);
        return 0;
    }
    for (int i = 0; i < 12; i++) {
        bin_str[11 - i] = (num & (1 << i)) ? '1' : '0';
    }
    bin_str[12] = '\0'; // Null-terminate the string
    return 1;
}
char short_to_base64(unsigned short num, char *base64_str) {
    if (!base64_str) {
        print_errors(ERROR_NUM_2);
        return 0;
    }
    /*Maps the 12 bits to two characters in Base64*/
    const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    base64_str[0] = base64_chars[(num >> 6) & 0x3F];  // Bits 11–6
    base64_str[1] = base64_chars[num & 0x3F];         // Bits 5–0
    base64_str[2] = '\0';
    return 1;
}