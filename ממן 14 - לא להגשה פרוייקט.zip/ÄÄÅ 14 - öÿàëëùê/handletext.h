

#ifndef HANDLETEXT_H
#define HANDLETEXT_H
#include <stdio.h>

/*The purpose of the function is to remove unnecessary spaces from the beginning, end, or between words.*/
void remove_whitespace_str(char str[]);

/*The purpose of the function is to copy a text from a file, starting from the current position, for a given length.
 *It returns a pointer to the copied text, or NULL if an error occurs.*/
char *copy_text(FILE *fp, fpos_t *pos, int length);

/*Helper function to check if a character is a space or a tab.*/
int is_space_or_tab(char c);

/*The purpose of the function is to remove spaces and tabs before and after a comma.*/
void remove_spaces_next_to_comma(char *str);

#endif //HANDLETEXT_H
