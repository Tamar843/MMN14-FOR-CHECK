

#ifndef LEXER_H
#define LEXER_H

typedef struct inst_parts {
    char *label;     /*Label name after .entry or .extern*/
    char *instruction;  /*Prompt type (.data / .string / .extern / .entry)*/
    char *data;      /*Prompt value if any (e.g. numbers)*/
} inst_parts;

/*The purpose of the function is to check if a label is valid, it goes through each character and checks if it is a letter or a number.*/
int is_valid_label(char *label);

/*The purpose of the function is to check if an assembly instruction*/
int is_opcode(char *command);

/*Checks if the string is r0 to r7*/
int is_register(char *operand);

/*Checks if the string is a valid data directive (.data, .string, .entry, .extern)*/
int is_instruction(char *word);

/*Identifies whether a string is a valid number
(positive or negative)*/
int is_number(char *str);


#endif //LEXER_H
