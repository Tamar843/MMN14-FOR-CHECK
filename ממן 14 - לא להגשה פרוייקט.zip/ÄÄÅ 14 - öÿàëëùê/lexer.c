#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "first_pass.h"
#include "handletext.h"
#include "global.h"
#include "lexer.h"

#include <ctype.h>

#include "util.h"
#include "ErrorMessage.h"

const char *INSTRUCTIONS[] = {".data", ".string", ".extern", ".entry"};

/* Instruction opcodes */
typedef enum {
    mov = 0,
    cmp = 1,
    add = 2,
    sub = 3,
    not = 4,
    clr = 5,
    lea = 6,
    inc = 7,
    dec = 8,
    jmp = 9,
    bne = 10,
    red = 11,
    prn = 12,
    jsr = 13,
    rts = 14,
    stop = 15
} opcode_t;

int is_valid_label(char *label) {
    int i = 0;
    int len = 0;
    if (!isalpha(label[0])) { /*First character must be a letter*/
        return 0;
    }

    while (label[i] != '\0' && label[i] != ':') { /*Scans the label to the end of the string or to:*/
        if (!isalnum(label[i]))
            return 0;
        i++;
        len++;
        if (len > MAX_LABEL_LENGTH) {
            return 0;
        }
    }
    if (is_opcode(label) || is_instruction(label) || is_register(label)) { /*Checking if the label is not a reserved name*/
        return 0;
    }

    if (len == 0) {
        return 0;
    }
    if (label[i] == ':') {
        label[i] = '\0';
    }

    return 1;
}
int is_opcode(char *command) {
    if (strcmp(command, "mov") == 0 || strcmp(command, "cmp") == 0 ||
        strcmp(command, "add") == 0 || strcmp(command, "sub") == 0 ||
        strcmp(command, "not") == 0 || strcmp(command, "clr") == 0 ||
        strcmp(command, "lea") == 0 || strcmp(command, "inc") == 0 ||
        strcmp(command, "dec") == 0 || strcmp(command, "jmp") == 0 ||
        strcmp(command, "bne") == 0 || strcmp(command, "red") == 0 ||
        strcmp(command, "prn") == 0 || strcmp(command, "jsr") == 0 ||
        strcmp(command, "rts") == 0 || strcmp(command, "stop") == 0) {
        return 1; /*Its a valid opcode*/
    }
    return 0; /*Not a valid opcode*/
}


int is_register(char *operand) {
    if (operand[0] == 'r' && isdigit(operand[1]) && operand[2] == '\0') {
        int reg_num = operand[1] - '0';
        if (reg_num >= 0 && reg_num <= 7) {
            return 1; /*It's a valid register*/
        }
    }
    return 0; /*Not a valid register*/
}

int is_instruction(char *word) {
    for (int i = 0; i < INSTRUCTIONS_COUNT; i++) {
        if (strcmp(word, INSTRUCTIONS[i]) == 0) {
            return 1; /*Its a valid instruction*/
        }
    }
    return 0; /* Not a valid instruction*/

}
int is_number(char *str) {
    if (str == NULL || *str == '\0')
        return 0;

    if (*str == '+' || *str == '-') {
        str++;
        if (*str == '\0') return 0;
    }

    while (*str) {
        if (!isdigit((unsigned char)*str))
            return 0;
        str++;
    }

    return 1;
}
