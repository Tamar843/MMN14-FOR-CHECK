#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "preproc.h"
#include "ErrorMessage.h"
#include "global.h"


mcro_table* new_table(void) {
    mcro_table* new_table = (mcro_table*) malloc(sizeof(mcro_table));
    if (new_table) {
        new_table->macros = NULL; /*Pointer to the start of the linked list*/
        new_table->count = 0; /*Variable for counting macros, starting from 0*/
    } else {
        print_errors(ERROR_NUM_2); /*If the allocation fails, it is notified.*/
    }
    return new_table;
}

int add_mcro(const char* filename, mcro_table* table) {
    FILE *file = fopen(filename, "r");
    int inside_mcro = 0; /*Flag whether we are inside a macro*/
    mcro *curr_mcro = NULL;
    if (!file) {
        print_errors(ERROR_NUM_1);
        return 0;
    }
    char line[MAX_LINE_LENGTH];
    while (fgets(line, MAX_LINE_LENGTH, file)) {
        line[strcspn(line, "\n")] = 0; /*Removes \n at the end*/
        if (strncmp(line, "mcro", 4) == 0) { /*If the line starts with a mcro*/
            if (inside_mcro) {
                print_errors(ERROR_NUM_4);
                continue;
            }
            inside_mcro = 1;
            curr_mcro = (mcro*)malloc(sizeof(mcro));
            if (!curr_mcro) {
                print_errors(ERROR_NUM_2);
                fclose(file);
                return 0;
            }
            sscanf(line, "mcro %s", curr_mcro->name);
            curr_mcro->line_num = 0;
            curr_mcro->next = NULL;
            if (strlen(curr_mcro->name) == 0) { /*Checks if the macro name already exists.*/
                print_errors(ERROR_NUM_3);
                free(curr_mcro);
                fclose(file);
                return 0;
            }
            if (find_mcro(table, curr_mcro->name)) {
                print_errors(ERROR_NUM_3);
                free(curr_mcro);
                fclose(file);
                return 0;
            }
        } else if (strncmp(line, "endmcro", 7) == 0) { /*Is the line endmcro*/
            if (!inside_mcro) {
                print_errors(ERROR_NUM_5); /*Error about finishing before starting*/
                continue;
            }

            /***********************************/
            /*Inserts the macro into the linked list*/
            curr_mcro->next = table->macros;
            table->macros = curr_mcro;
            /***********************************/


            table->count++;
            inside_mcro = 0;
            curr_mcro = NULL;
        } else if (inside_mcro) {
            if (curr_mcro->line_num < MAX_MCRO_LINES) {
                strcpy(curr_mcro->line[curr_mcro->line_num], line); /*Saves the line*/
                curr_mcro->line_num++;
            } else {
                print_errors(ERROR_NUM_6);
                free(curr_mcro);
                fclose(file);
                return 0;
            }
        }
    }
    if (inside_mcro) {
        print_errors(ERROR_NUM_5);
        if (curr_mcro) free(curr_mcro);
        fclose(file);
        return 0;
    }
    fclose(file);
    return 1;
}

mcro* find_mcro(mcro_table* table, const char *name) {
    mcro* curr = table->macros;
    while (curr) { /*As long as there is a macro*/
        if (strcmp(curr->name, name) == 0) {
            return curr;
        }
        curr = curr->next;
    }
    return NULL;
}

int replace_mcro(const char *input_file, const char *output_file, mcro_table *table) {
    int i;
    FILE *file = fopen(input_file, "r");
    FILE *outfile = fopen(output_file, "w");
    if (!file || !outfile) {
        print_errors(ERROR_NUM_1);
        if (file) fclose(file);
        if (outfile) fclose(outfile);
        return 0;
    }
    char line[MAX_LINE_LENGTH];
    char  original_line[MAX_LINE_LENGTH];
    while (fgets(line, MAX_LINE_LENGTH, file)) {
        strcpy( original_line, line); /*Saves a copy of the original row*/
        line[strcspn(line, "\n")] = 0;
         original_line[strcspn( original_line, "\n")] = 0;
        if (strlen(line) == 0) {
            fprintf(outfile, "%s\n",  original_line);
            continue;
        }

        if (strncmp( original_line, "mcro", 4) == 0 || strncmp( original_line, "endmcro", 7) == 0) {
            continue;
        }
        char temp_line[MAX_LINE_LENGTH];
        strcpy(temp_line, original_line);
        char *word = strtok(temp_line, " ");
        if (word) {
            mcro *found_mcro = find_mcro(table, word); /*Looking for if it is the name of a macro*/
            if (found_mcro) {
                for (i = 0; i < found_mcro->line_num; i++) {
                    fprintf(outfile, "%s\n", found_mcro->line[i]);
                }
            } else {
                fprintf(outfile, "%s\n",  original_line);
            }
        } else {
            fprintf(outfile, "%s\n",  original_line);
        }
    }
    fclose(file);
    fclose(outfile);
    return 1;
}

int mcro_exec(const char *input_file, const char *output_file) {
    mcro_table *table = new_table();
    if (!table) return 0;
    if (!add_mcro(input_file, table)) {
        free_mcro(table);
        return 0;
    }
    if (!replace_mcro(input_file, output_file, table)) {
        free_mcro(table);
        return 0;
    }
    free_mcro(table);
    return 1;
}

void free_mcro(mcro_table *table) {
    if (!table) return;
    mcro *curr_mcro = table->macros;
    while (curr_mcro) {
        mcro *next = curr_mcro->next;
        free(curr_mcro);
        curr_mcro = next;
    }
    free(table);
}

